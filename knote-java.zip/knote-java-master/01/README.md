# knote-java

Simple Spring Boot app to take notes
